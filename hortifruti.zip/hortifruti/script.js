// Lista com os nomes dos produtos do hortifruti
const produtos = [
    "Banana",
    "Maçã",
    "Cenoura",
    "Batata",
    "Alface",
    "Couve"
];

// Categoria de cada produto
const categorias = [
    "Fruta",
    "Fruta",
    "Legume",
    "Legume",
    "Verdura",
    "Verdura"
];

// Preço médio dos produtos
const precos = [
    "R$ 6,99 / kg",
    "R$ 8,99 / kg",
    "R$ 5,49 / kg",
    "R$ 4,99 / kg",
    "R$ 3,50 / unidade",
    "R$ 4,00 / maço"
];

// Descrição de cada produto
const descricoes = [
    "Banana madura, doce e ótima para consumo no dia a dia.",
    "Maçã fresca, crocante e de sabor levemente adocicado.",
    "Cenoura fresca, firme e indicada para saladas e receitas.",
    "Batata selecionada, ideal para fritar, cozinhar ou assar.",
    "Alface fresca e crocante, ótima para saladas.",
    "Couve fresca, indicada para saladas, sucos e refogados."
];

// Imagens dos produtos
const imagens = [
    "https://images.unsplash.com/photo-1571771894821-ce9b6c11b08e?auto=format&fit=crop&w=300&q=80",
    "https://images.unsplash.com/photo-1560806887-1e4cd0b6cbd6?auto=format&fit=crop&w=300&q=80",
    "https://images.unsplash.com/photo-1445282768818-728615cc910a?auto=format&fit=crop&w=300&q=80",
    "https://images.unsplash.com/photo-1518977676601-b53f82aba655?auto=format&fit=crop&w=300&q=80",
    "https://images.unsplash.com/photo-1622205313162-be1d5712a43c?auto=format&fit=crop&w=300&q=80",
    "https://images.unsplash.com/photo-1576045057995-568f588f82fb?auto=format&fit=crop&w=300&q=80"
];

// Mapeamento dos elementos da página
const selectProdutos = document.getElementById("selectProdutos");
const btnDetalhes = document.getElementById("btnDetalhes");

const divCategoria = document.getElementById("divCategoria");
const divNome = document.getElementById("divNome");
const divPreco = document.getElementById("divPreco");
const divDescricao = document.getElementById("divDescricao");
const divImagem = document.getElementById("divImagem");

// Evento do botão "Detalhes"
btnDetalhes.addEventListener("click", function() {

    // Pega o índice selecionado na lista
    const index = selectProdutos.value;

    // Verifica se existe uma seleção válida
    if (index !== "") {

        // Mostra a categoria
        divCategoria.textContent = categorias[index];

        // Mostra o nome
        divNome.textContent = produtos[index];

        // Mostra o preço
        divPreco.textContent = precos[index];

        // Mostra a descrição
        divDescricao.textContent = descricoes[index];

        // Mostra a imagem
        divImagem.innerHTML =
            `<img src="${imagens[index]}" alt="Imagem de ${produtos[index]}">`;
    }
});
